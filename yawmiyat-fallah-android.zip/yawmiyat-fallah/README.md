# يوميات الفلاح — Projet Android

## 📱 Description
Application de calendrier agricole marocain.
- 20 régions agricoles du Maroc
- 64 produits agricoles classés en 8 catégories
- 8 thèmes de couleur
- Calendrier amazigh avec périodes agricoles traditionnelles
- Notifications intelligentes par région et saison

---

## 🛠️ Compiler l'APK — Instructions

### Prérequis
- **Android Studio** (gratuit) → https://developer.android.com/studio
- **JDK 11+** (inclus avec Android Studio)
- **SDK Android** (installé automatiquement par Android Studio)

---

### Étape 1 — Ouvrir le projet

1. Lancer **Android Studio**
2. Cliquer **"Open"**
3. Sélectionner le dossier `yawmiyat-fallah`
4. Attendre la synchronisation Gradle (~2 min la première fois)

---

### Étape 2 — Compiler l'APK Debug (rapide, pour tester)

```
Menu → Build → Build Bundle(s) / APK(s) → Build APK(s)
```

L'APK sera dans :
```
app/build/outputs/apk/debug/app-debug.apk
```

---

### Étape 3 — Compiler l'APK Release (pour distribution)

```
Menu → Build → Generate Signed Bundle / APK
```

Choisir **APK** puis créer un keystore (signature) :
1. Cliquer **"Create new..."**
2. Remplir les informations (mot de passe, nom, etc.)
3. Cliquer **Finish**

L'APK signé sera dans :
```
app/build/outputs/apk/release/app-release.apk
```

---

### Étape 4 — Installer sur téléphone

**Option A — Via USB :**
1. Activer "Options développeur" sur votre téléphone
2. Activer "Débogage USB"
3. Connecter via USB
4. Dans Android Studio → Run → Run 'app'

**Option B — Copier l'APK :**
1. Copier `app-debug.apk` sur le téléphone
2. Ouvrir avec le gestionnaire de fichiers
3. Installer (autoriser les sources inconnues si demandé)

---

## 📁 Structure du projet

```
yawmiyat-fallah/
├── app/
│   ├── src/main/
│   │   ├── assets/
│   │   │   └── index.html          ← L'application complète
│   │   ├── java/com/yawmiyat/fallah/
│   │   │   └── MainActivity.java   ← WebView + Bridge Android
│   │   ├── res/
│   │   │   ├── layout/
│   │   │   │   └── activity_main.xml
│   │   │   ├── mipmap-*/           ← Icônes (toutes densités)
│   │   │   └── values/
│   │   │       ├── strings.xml
│   │   │       └── themes.xml
│   │   └── AndroidManifest.xml
│   ├── build.gradle
│   └── proguard-rules.pro
├── build.gradle
├── settings.gradle
├── gradle.properties
└── gradle/wrapper/
    └── gradle-wrapper.properties
```

---

## ⚙️ Configuration

| Paramètre | Valeur |
|-----------|--------|
| Package | `com.yawmiyat.fallah` |
| minSdk | 21 (Android 5.0+) |
| targetSdk | 34 (Android 14) |
| Version | 1.0.0 |
| Orientation | Portrait uniquement |

---

## 🔧 Personnalisation

Pour modifier le contenu de l'app, éditer :
```
app/src/main/assets/index.html
```
Puis recompiler l'APK.

---

## 📝 Notes techniques

- L'app utilise **WebView** pour afficher le HTML/JS
- **LocalStorage** fonctionne normalement dans WebView
- Le bridge `AndroidBridge` permet au JS de communiquer avec Android
- L'app est **entièrement offline** — aucune connexion internet requise
