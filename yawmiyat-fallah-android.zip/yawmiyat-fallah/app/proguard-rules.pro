-keep class com.yawmiyat.fallah.** { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
