package com.yawmiyat.fallah;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowInsetsController;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

public class MainActivity extends AppCompatActivity {

    private WebView webView;

    @SuppressLint({"SetJavaScriptEnabled", "WrongViewCast"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Plein écran avec barre de statut transparente
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);

        // Icônes claires sur fond sombre
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            WindowInsetsControllerCompat controller =
                WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
            controller.setAppearanceLightStatusBars(false);
            controller.setAppearanceLightNavigationBars(false);
        }

        setContentView(R.layout.activity_main);
        webView = findViewById(R.id.webview);

        configureWebView();
        addJavascriptBridge();
        loadApp();
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureWebView() {
        WebSettings settings = webView.getSettings();

        // JavaScript et stockage
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);

        // Cache et performance
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);

        // Affichage
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);

        // Encodage
        settings.setDefaultTextEncodingName("UTF-8");

        // Cookies
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        // Accélération matérielle
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        webView.setBackgroundColor(Color.parseColor("#080f08"));

        // WebViewClient — intercepte la navigation
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                // Garder la navigation dans le WebView
                if (url.startsWith("file://") || url.startsWith("about:")) {
                    return false;
                }
                return true; // bloquer navigation externe
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // Injecter le padding pour la status bar
                injectStatusBarPadding();
            }
        });

        // WebChromeClient — pour les dialogs JS etc.
        webView.setWebChromeClient(new WebChromeClient());
    }

    private void addJavascriptBridge() {
        webView.addJavascriptInterface(new AndroidBridge(this), "AndroidBridge");
    }

    private void loadApp() {
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void injectStatusBarPadding() {
        // Récupérer la hauteur de la status bar et l'injecter en CSS
        int statusBarHeight = getStatusBarHeight();
        String js = String.format(
            "document.documentElement.style.setProperty('--status-bar-height', '%dpx');" +
            "var topbar = document.querySelector('.topbar');" +
            "if(topbar) { topbar.style.paddingTop = '%dpx'; topbar.style.height = (48 + %d) + 'px'; }",
            statusBarHeight, statusBarHeight, statusBarHeight
        );
        webView.evaluateJavascript(js, null);
    }

    private int getStatusBarHeight() {
        int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            return getResources().getDimensionPixelSize(resourceId);
        }
        return 0;
    }

    // ── Bridge JavaScript → Android ──────────────────────────────
    public static class AndroidBridge {
        private final Context context;

        AndroidBridge(Context ctx) { this.context = ctx; }

        @JavascriptInterface
        public void showToast(String message) {
            ((Activity) context).runOnUiThread(() ->
                Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
            );
        }

        @JavascriptInterface
        public String getDeviceInfo() {
            return Build.MODEL + " / Android " + Build.VERSION.RELEASE;
        }

        @JavascriptInterface
        public boolean isAndroid() { return true; }
    }

    // ── Cycle de vie ──────────────────────────────────────────────
    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (webView != null) webView.onPause();
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
